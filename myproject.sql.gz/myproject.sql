--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `Gname` varchar(40) NOT NULL,
  `Gid` varchar(40) NOT NULL,
  `Gtype` varchar(40) NOT NULL,
  `Gdesc` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`Gname`, `Gid`, `Gtype`, `Gdesc`) VALUES
('Call Of Duty', 'CA-55', 'War', 'War Events'),
('Good Game', 'G-00', 'Good', 'Hello'),
('GTA', 'GTA-222', 'Action', 'Hello World'),
('Horror House', 'HH-00', 'Death', 'Good Game'),
('Medal Of Honor', 'MA-2000', 'Action', 'War'),
('Need For Speed', 'NA-55', 'Action', 'Car Driving'),
('Quiz2', 'Q-45', 'Action', 'Quizes'),
('Quiz1', 'Q-66', 'Action', 'Quizes');

-- --------------------------------------------------------

--
-- Table structure for table `register_user_info`
--

CREATE TABLE `register_user_info` (
  `User_Name` varchar(30) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Password` int(11) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Age` int(11) NOT NULL,
  `User_Type` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_user_info`
--

INSERT INTO `register_user_info` (`User_Name`, `User_ID`, `Password`, `Address`, `Phone`, `Age`, `User_Type`, `Gender`) VALUES
('Mona', 0, 0, '000000', '000000', 0, 'Teacher', 'Female'),
('Khaled', 6666, 2055, '6666', '666', 666, 'Teacher', 'Female'),
('Hamo', 8888, 0, 'Here', '000000', 0, 'Student', 'Male'),
('Hany', 11111, 11111, 'America', '2234660', 44, 'Teacher', 'Male'),
('Hoda', 77777, 7777777, '777777', '777777', 77777, 'Teacher', 'Female'),
('Fatma', 555555, 555555, '555555', '555555', 555555, 'Student', 'Female'),
('Ahmed Hosny', 20100894, 123456789, 'Ciro', '01255668899', 55, 'Teacher', 'Male'),
('Maher', 20130029, 12345, 'Behera', '01010177204', 21, 'Student', 'Male'),
('Mohamed', 20130194, 2234660, 'Cairo', '01124274710', 23, 'Teacher', 'Male'),
('Omnia', 20140071, 123456, 'Ciro', '01284277001', 21, 'Student', 'Female'),
('Raja', 20140118, 666666, 'Alex', '01224209036', 22, 'Student', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `User_Name` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `User_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`User_Name`, `Password`, `User_ID`) VALUES
('Khaled', '2055', 6666),
('Hamo', '000000', 8888),
('Hany', '11111', 11111),
('Hoda', '7777777', 77777),
('Fatma', '555555', 555555),
('Ahmed Hosny', '123456789', 20100894),
('Maher', '12345', 20130029),
('Mohamed', '2234660', 20130194),
('Omnia', '123456', 20140071),
('Raja', '666666', 20140118);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`Gid`);

--
-- Indexes for table `register_user_info`
--
ALTER TABLE `register_user_info`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`User_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
